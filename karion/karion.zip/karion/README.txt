For UNIX users, Put the 'Karion.exe' and 'karion'
into the /bin folder:

% sudo mv Karion.exe /bin && mv karion /bin

Then you can simply run Karion from the terminal

NOTICE:
In UNIX systems you need to have Mono installed